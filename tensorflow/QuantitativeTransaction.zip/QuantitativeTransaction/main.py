__author__ = 'Cila'

import os
import pprint
import numpy as np
import matplotlib.pyplot as plt
import sklearn.preprocessing as prep
import pymysql as mysql

from data_model import StockDataSet

import tensorflow as tf
import tensorflow.contrib.slim as slim
import tflearn

flags = tf.app.flags
flags.DEFINE_integer("stock_count", 100, "Stock count [100]")
flags.DEFINE_integer("input_size", 10, "Input size [10]")
flags.DEFINE_integer("num_steps", 20, "Num of steps [30]")
flags.DEFINE_integer("batch_size", 64, "The size of batch images [64]")
flags.DEFINE_float("keep_prob", 0.8, "Keep probability of dropout layer. [0.8]")
flags.DEFINE_float("init_learning_rate",0.001, "Initial learning rate at early stage. [0.001]")
flags.DEFINE_float("learning_rate_decay", 0.99, "Decay rate of learning rate. [0.99]")
flags.DEFINE_integer("init_epoch", 100, "Num. of epoches considered as early stage. [5]")
flags.DEFINE_string("stock_symbol", 'RB1805', "Target stock symbol [None]")
flags.DEFINE_string("type", 'RB', "Target stock type [None]")
flags.DEFINE_string("contract_multiplier", 10, "Target stock contract_multiplier [None]")
flags.DEFINE_boolean("train", False, "True for training, False for testing [False]")

FLAGS = flags.FLAGS

pp = pprint.PrettyPrinter()

def show_all_variables():
    model_vars = tf.trainable_variables()
    slim.model_analyzer.analyze_vars(model_vars, print_info=True)

def load_data(input_size, num_steps, k=None, target_symbol=None, test_ratio=0):
    if target_symbol is not None:
        return [StockDataSet(
                target_symbol,
                initCsv=False,
                input_size=input_size,
                num_steps=num_steps,
                test_ratio=test_ratio)]
    return [StockDataSet(stock_sym='data15min',
                     sheet='Sheet1',
                     input_size=input_size,
                     num_steps=num_steps,
                     test_ratio=test_ratio)]


def main(_):
    pp.pprint(flags.FLAGS.__flags)
    #tflearn lstm
    name = "stock_rnn_lstm_%s" % (FLAGS.stock_symbol)

    net = tflearn.input_data(shape=[None,FLAGS.num_steps,FLAGS.input_size])
    net = tflearn.lstm(net, 128, return_seq=True)
    net = tflearn.lstm(net, 64)
    net = tflearn.fully_connected(net,1)
    net = tflearn.regression(net, optimizer='adam',loss='mean_square')
    model = tflearn.DNN(net,tensorboard_verbose=0)

    stock_data_list = load_data(
                FLAGS.input_size,
                FLAGS.num_steps,
                k=FLAGS.stock_count,
                target_symbol=FLAGS.stock_symbol,
            )
    train_x = stock_data_list[0].train_X
    if FLAGS.train:
        x1 = standard_scale(train_x,train_x)
        x = []
        for j in range(FLAGS.num_steps,len(x1)+1):
            temp = x1[j-FLAGS.num_steps:j]
            x.append(temp)
        x1 = np.array(x)
        train_y = stock_data_list[0].train_y[FLAGS.num_steps-1:]
        model.fit(x1,train_y,n_epoch=5,validation_set=0.1,show_metric=True,snapshot_step=100,batch_size=FLAGS.batch_size)
        model.save(os.path.join("logs", name))
    model.load(os.path.join("logs", name))
    test_x = stock_data_list[0].GetTestData('RB18051128')
    test_x = standard_scale(train_x,test_x)
    x = []
    test_x = np.append(train_x[-19:],test_x,axis=0)
    for j in range(FLAGS.num_steps,len(test_x)+1):
        temp = test_x[j-FLAGS.num_steps:j]
        x.append(temp)
    test_x = np.array(x)
    prediction = model.predict(test_x)
    trade(stock_data_list,prediction)
    plot()



def standard_scale(fit,data):
    preprocessor = prep.StandardScaler().fit(fit)
    data = preprocessor.transform(data)
    return data

def trade(dataset_list,signal):
    capital = 400000
    RawPrice = dataset_list[0].raw_test_price
    Date = dataset_list[0].date
    f60_position = np.zeros(len(signal))
    f60_position[0] = 0
    for i in range(1,len(signal)):
        if signal[i] >= 0 and f60_position[i-1] >= 0:
            f60_position[i] = 1
        elif  signal[i] <= 0 and f60_position[i-1] <= 0:
            f60_position[i] = -1
        elif  signal[i] * f60_position[i-1] < 0:
            f60_position[i] = 0
    saveMysql(RawPrice,f60_position,Date)

def saveMysql(price,position,date):
    db = mysql.connect("localhost","root","init1234","entropy")
    for i in range(len(price)):
        check_sql = "SELECT * FROM trade WHERE type = '%s' and date = '%s'" % (FLAGS.type,date[i])
        cursor = db.cursor()
        cursor.execute(check_sql)
        results = cursor.fetchone()
        if results:
            sql = "UPDATE trade SET price = '%.2f',position = '%d' WHERE date = '%s'" % (price[i],position[i],date[i])
        else:
            sql = "INSERT INTO trade(price,position, type, contract_multiplier,date) VALUES ('%.2f', '%d', '%s', '%d','%s')" % (price[i],position[i],FLAGS.type,FLAGS.contract_multiplier,date[i])
        try:
           # 执行sql语句
           cursor = db.cursor()
           print(sql)
           cursor.execute(sql)
           # 提交到数据库执行
           db.commit()
        except:
           # 如果发生错误则回滚
           db.rollback()
    # 关闭数据库连接
    db.close()

def plot():
    db = mysql.connect("localhost","root","init1234","entropy")
    cursor = db.cursor()
    search_sql = "SELECT * FROM trade WHERE type = '%s'" % (FLAGS.type)
    cursor.execute(search_sql)
    results = cursor.fetchall()
    tradetimes = 0
    f60_fee = np.zeros(len(signal))
    f60_slide = np.zeros(len(signal))
    bigpoint = 300
    for i in range(1,len(signal)):
        if(f60_position[i] != f60_position[i-1]):
            tradetimes = tradetimes +1
            #期货
            #  fee 1e-4 * 300
            #  slide  0.2 * 300
            f60_fee[i] = - RawPrice[i]* 1e-4 * bigpoint
            f60_slide[i] = - 0.2 * bigpoint
            #股票
            # f60_fee[i] = - RawPriceNow[i]*0.001*bigpoint
            # f60_slide[i] = - 0.1 * bigpoint

    f60_cost = np.add(f60_fee,f60_slide)

    print(tradetimes)

    chajia = np.diff(RawPrice,axis=0)
    chajia = chajia[-len(signal) + 1:]

    f60_r = np.cumsum(np.multiply(f60_position[:-1],chajia) * bigpoint + f60_cost[1:]) + capital

    plt.figure(2)
    plt.plot(f60_r, color='b')
    plt.grid(True)
    plt.show()



if not os.path.exists("logs"):
    os.mkdir("logs")

if __name__ == '__main__':
    tf.app.run()