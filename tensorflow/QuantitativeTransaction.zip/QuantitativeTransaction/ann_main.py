__author__ = 'Cila'
import os
import pprint
import numpy as np
import matplotlib.pyplot as plt
import sklearn.preprocessing as prep

from data_model import StockDataSet
from ann_model import ANN
from rnn_model import LstmRNN

import tensorflow as tf
import tensorflow.contrib.slim as slim
import tflearn

flags = tf.app.flags
flags.DEFINE_integer("stock_count", 100, "Stock count [100]")
flags.DEFINE_integer("input_size", 10, "Input size [10]")
flags.DEFINE_integer("num_steps", 1, "Num of steps [30]")
flags.DEFINE_integer("num_layers", 8, "Num of layer [1]")
flags.DEFINE_integer("hidden_size", 40, "Size of hidden_units")
flags.DEFINE_integer("batch_size", 100, "The size of batch images [64]")
flags.DEFINE_float("keep_prob", 0.8, "Keep probability of dropout layer. [0.8]")
flags.DEFINE_float("init_learning_rate", 3e-5, "Initial learning rate at early stage. [0.001]")
flags.DEFINE_float("learning_rate_decay", 0.99, "Decay rate of learning rate. [0.99]")
flags.DEFINE_integer("init_epoch", 100, "Num. of epoches considered as early stage. [5]")
flags.DEFINE_integer("max_epoch", 20000, "Total training epoches. [50]")
flags.DEFINE_integer("embed_size", None, "If provided, use embedding vector of this size. [None]")
flags.DEFINE_string("stock_symbol", None, "Target stock symbol [None]")
flags.DEFINE_boolean("train", True, "True for training, False for testing [False]")

FLAGS = flags.FLAGS

pp = pprint.PrettyPrinter()

def show_all_variables():
    model_vars = tf.trainable_variables()
    slim.model_analyzer.analyze_vars(model_vars, print_info=True)

def load_data(input_size, num_steps, k=None, target_symbol=None, test_ratio=0.01):
    if target_symbol is not None:
        return [StockDataSet(
                target_symbol,
                input_size=input_size,
                num_steps=num_steps,
                test_ratio=test_ratio)]
    return [StockDataSet(stock_sym='data15min',
                     sheet='Sheet1',
                     input_size=input_size,
                     num_steps=num_steps,
                     test_ratio=test_ratio)]

def main(_):
    pp.pprint(flags.FLAGS.__flags)
    stock_data_list = load_data(
            FLAGS.input_size,
            FLAGS.num_steps,
            k=FLAGS.stock_count,
            target_symbol=FLAGS.stock_symbol,
        )
    train_signal1 = []
    train_signal2 = []
    train_signal3 = []
    train_index1 = []
    train_index2 = []
    train_index3 = []
    for i in range(len(stock_data_list[0].train_X)):
        if stock_data_list[0].train_state[i] == 1:
            train_index1.append(stock_data_list[0].train_X[i])
            train_signal1.append(stock_data_list[0].train_y[i])
        elif stock_data_list[0].train_state[i] == 2:
            train_index2.append(stock_data_list[0].train_X[i])
            train_signal2.append(stock_data_list[0].train_y[i])
        else:
            train_index3.append(stock_data_list[0].train_X[i])
            train_signal3.append(stock_data_list[0].train_y[i])

    prediction = np.zeros(len(stock_data_list[0].test_X))
    a = []
    b = []
    c = []
    a_index = 0
    b_index = 0
    c_index = 0
    for i in range(len(stock_data_list[0].test_X)):
        if stock_data_list[0].test_state[i] == 1:
            a.append(stock_data_list[0].test_X[i])
            prediction[i] = 1
        elif stock_data_list[0].test_state[i] == 2:
            b.append(stock_data_list[0].test_X[i])
            prediction[i] = 2
        else:
            c.append(stock_data_list[0].test_X[i])
            prediction[i] = 3
    x1 = standard_scale(train_index1,train_index1)
    x2 = standard_scale(train_index2,train_index2)
    x3 = standard_scale(train_index3,train_index3)
    if(len(a)>0):
        a = standard_scale(train_index1,a)
    if(len(b)>0):
        b = standard_scale(train_index2,b)
    if(len(c)>0):
        c = standard_scale(train_index3,c)

    # net1 = LstmRNN(
    #     FLAGS.stock_count,
    #     name='net1',
    #     lstm_size=FLAGS.hidden_size,
    #     num_layers=FLAGS.num_layers,
    #     num_steps=FLAGS.num_steps,
    #     input_size=FLAGS.input_size,
    #     keep_prob=FLAGS.keep_prob,
    #     embed_size=FLAGS.embed_size
    # )
    # show_all_variables()
    # train_x = stock_data_list[0].train_X
    # if FLAGS.train:
    #     x1 = standard_scale(train_x,stock_data_list[0].train_X)
    #     stock_data_list[0].train_X = x1
    #     net1.train(stock_data_list, FLAGS)
    # if not net1.load()[0]:
    #     raise Exception("[!] Train a model first, then run test mode")
    # # if len(a)>0:
    # test_x = standard_scale(train_x,stock_data_list[0].test_X)
    # prediction = net1.prediction(test_x)

    # net2 = LstmRNN(
    #     FLAGS.stock_count,
    #     name='net2',
    #     num_layers=FLAGS.num_layers,
    #     num_steps=FLAGS.num_steps,
    #     input_size=FLAGS.input_size,
    #     keep_prob=FLAGS.keep_prob,
    #     embed_size=FLAGS.embed_size
    # )
    # show_all_variables()
    #
    # if FLAGS.train:
    #     stock_data_list[0].train_X = x2
    #     stock_data_list[0].train_y = train_signal2
    #     net2.train(stock_data_list, FLAGS)
    # if not net2.load()[0]:
    #     raise Exception("[!] Train a model first, then run test mode")
    # if len(b)> 0:
    #     prediction2 = net2.prediction(b)
    #
    # net3 = LstmRNN(
    #     FLAGS.stock_count,
    #     name='net3',
    #     num_layers=FLAGS.num_layers,
    #     num_steps=FLAGS.num_steps,
    #     input_size=FLAGS.input_size,
    #     keep_prob=FLAGS.keep_prob,
    #     embed_size=FLAGS.embed_size
    # )
    #
    # show_all_variables()
    #
    # if FLAGS.train:
    #     stock_data_list[0].train_X = x3
    #     stock_data_list[0].train_y = train_signal3
    #     net3.train(stock_data_list, FLAGS)
    # if not net3.load()[0]:
    #     raise Exception("[!] Train a model first, then run test mode")
    # if len(c) > 0:
    #     prediction3 = net3.prediction(c)

    model1 = create_network()
    model1.fit(x1,train_signal1,n_epoch=20,show_metric=True,batch_size=64)
    if len(a)> 0:
        prediction1 = model1.predict(a)

    model2 = create_network()
    model2.fit(x2,train_signal2,n_epoch=20,show_metric=True,batch_size=64)
    if len(b)> 0:
        prediction2 = model2.predict(b)

    model3 = create_network()
    model3.fit(x3,train_signal3,n_epoch=20,show_metric=True,batch_size=64)
    if len(c)> 0:
        prediction3 = model3.predict(c)

    for i in range(len(stock_data_list[0].test_X)):
        if prediction[i] == 1:
            prediction[i] = prediction1[a_index]
            a_index += 1
        elif prediction[i] == 2:
            prediction[i] = prediction2[b_index]
            b_index += 1
        else:
            prediction[i] = prediction3[c_index]
            c_index += 1
    trade(stock_data_list,prediction)

def create_network():
    with tf.Graph().as_default():
        net = tflearn.input_data(shape=[None,FLAGS.input_size])
        net = tflearn.fully_connected(net,25,activation='sigmoid')
        net = tflearn.fully_connected(net,1,activation='tanh')
        net = tflearn.regression(net, optimizer='adam',loss='mean_square',name='output1')
        model = tflearn.DNN(net,tensorboard_verbose=0)
    return model

def standard_scale(fit,data):
    preprocessor = prep.StandardScaler().fit(fit)
    data = preprocessor.transform(data)
    return data

def trade(dataset_list,signal):
    capital = 400000
    RawPrice = dataset_list[0].raw_price
    train_size = dataset_list[0].train_size
    f60_position = np.zeros(len(signal))
    f60_position[0] = 0
    for i in range(1,len(signal)):
        if signal[i] >= 0 and f60_position[i-1] >= 0:
            f60_position[i] = 1
        elif  signal[i] <= 0 and f60_position[i-1] <= 0:
            f60_position[i] = -1
        elif  signal[i] * f60_position[i-1] < 0:
            f60_position[i] = 0
    tradetimes = 0
    f60_fee = np.zeros(len(signal))
    f60_slide = np.zeros(len(signal))
    bigpoint = 300
    for i in range(1,len(signal)):
        if(f60_position[i] != 0):
            tradetimes = tradetimes +1
            #期货
            #  fee 1e-4 * 300
            #  slide  0.2 * 300
            f60_fee[i] = - RawPrice[i]* 1e-4 * bigpoint
            f60_slide[i] = - 0.2 * bigpoint
            #股票
            # f60_fee[i] = - RawPriceNow[i]*0.001*bigpoint
            # f60_slide[i] = - 0.1 * bigpoint

    f60_cost = np.add(f60_fee,f60_slide)

    print(tradetimes)

    chajia = np.diff(RawPrice,axis=0)
    d=0
    test_signal = dataset_list[0].test_y[FLAGS.num_steps-1:]
    chajia = chajia[-len(signal) + 1:]
    for i in range(len(test_signal)):
        if test_signal[i] * signal[i] < 0:
            d += 1
    print(d / len(test_signal) *100,'%')

    f60_r = np.cumsum(np.multiply(f60_position[:-1],chajia) * bigpoint + f60_cost[1:]) + capital
    plt.figure(1)
    plt.plot(test_signal,'b',signal,'r')
    plt.grid(True)
    plt.figure(2)
    plt.plot(f60_r, color='b')
    plt.grid(True)
    plt.show()

if not os.path.exists("logs"):
    os.mkdir("logs")

if __name__ == '__main__':
    tf.app.run()